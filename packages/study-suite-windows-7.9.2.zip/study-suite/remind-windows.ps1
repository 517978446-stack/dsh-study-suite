﻿# 学习助手 · Windows 提醒任务（截止 / 上课推送）
#
#   powershell -ExecutionPolicy Bypass -File remind-windows.ps1            安装（每 5 分钟检查一次）
#   powershell -ExecutionPolicy Bypass -File remind-windows.ps1 -Test      只跑一次，打印会推什么
#   powershell -ExecutionPolicy Bypass -File remind-windows.ps1 -Remove    移除任务
#
# 需要先装好服务（install.ps1）。任务用 pythonw.exe，不弹控制台窗口。
param(
  [switch]$Remove,
  [switch]$Test
)

$ErrorActionPreference = "Stop"
try {
  [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch { }

$Base = if ($env:STUDY_SUITE_HOME) { $env:STUDY_SUITE_HOME } else { Join-Path $env:USERPROFILE ".dsh-study-suite" }
$TaskName = "StudySuiteRemind"
$RemindPy = Join-Path $Base "remind.py"
$RunCmd = Join-Path $Base "run-remind.cmd"
$LogFile = Join-Path $Base "remind.log"

function ConvertTo-Crlf($text) {
  if ($text -match "(?<!`r)`n") { $text = $text -replace "(?<!`r)`n", "`r`n" }
  if (-not $text.EndsWith("`r`n")) { $text += "`r`n" }
  return $text
}

function Unregister-RemindTask {
  $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  if ($existing) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "== 已移除计划任务 $TaskName"
  } else {
    Write-Host "== 没有找到计划任务 $TaskName"
  }
}

if ($Remove) {
  Unregister-RemindTask
  if (Test-Path $RunCmd) { Remove-Item $RunCmd -Force }
  Write-Host "== 提醒任务已卸载（remind.log 保留）"
  exit 0
}

if (-not (Test-Path $RemindPy)) {
  Write-Host "!! 找不到 $RemindPy，请先运行 install.ps1"
  exit 1
}

# 找一个能跑 remind.py 的 python（优先 pythonw，避免闪窗）
$Py = $null
foreach ($candidate in @("pythonw.exe", "python.exe", "py.exe")) {
  $found = Get-Command $candidate -ErrorAction SilentlyContinue
  if ($found) { $Py = $found.Source; break }
}
if (-not $Py) {
  Write-Host "!! 没找到 Python，请先安装并加入 PATH"
  exit 1
}
if ($Py -like "*py.exe") {
  # py.exe 是启动器，不能用 pythonw 的话就用它带 -3 参数
  $Py = $Py
}

$CmdBase = if ($Base -eq (Join-Path $env:USERPROFILE ".dsh-study-suite")) {
  "%USERPROFILE%\.dsh-study-suite"
} else {
  $Base
}

$body = @"
@echo off
chcp 65001 >nul
set STUDY_SUITE_WORKSPACE=$CmdBase
set STUDY_SUITE_TOOLS=$CmdBase
set STUDY_SUITE_SECRETS=$CmdBase\secrets
set PYTHONPATH=$CmdBase\pylibs
set PYTHONIOENCODING=utf-8
rem 日志超过 2MB 就轮转
if exist "$CmdBase\remind.log" for %%F in ("$CmdBase\remind.log") do if %%~zF GTR 2097152 move /y "$CmdBase\remind.log" "$CmdBase\remind.log.1" >nul 2>&1
"$Py" "$CmdBase\remind.py" >> "$CmdBase\remind.log" 2>&1
"@
$body = ConvertTo-Crlf $body
# .cmd 不能带 BOM，否则 cmd.exe 会把 BOM 当成命令的一部分
[System.IO.File]::WriteAllText($RunCmd, $body, (New-Object System.Text.UTF8Encoding($false)))

if ($Test) {
  Write-Host "== 试跑一次（只打印，不推送）"
  & $Py $RemindPy --dry-run
  exit 0
}

# 每 5 分钟跑一次，开机后可用，电池上也照跑
$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument ('/c "' + $RunCmd + '"')
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) `
  -RepetitionInterval (New-TimeSpan -Minutes 5) `
  -RepetitionDuration (New-TimeSpan -Days 3650)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

Unregister-RemindTask | Out-Null
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger `
  -Settings $settings -Principal $principal -Description "学习助手：截止与上课提醒（每 5 分钟）" | Out-Null

Write-Host "== 已注册计划任务 $TaskName（每 5 分钟，日志 $LogFile）"
Write-Host "== 想立刻验证：powershell -ExecutionPolicy Bypass -File remind-windows.ps1 -Test"
