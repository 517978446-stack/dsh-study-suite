# 学习助手（Study Suite）

> **第一次安装请先看 [INSTALL.md](INSTALL.md)** —— 那是一份可以直接转发给朋友的完整说明。

装进 DeepSeek Harness 的本地学习面板：课程链接与动态、英中互译（中英对照）、语音转写与课堂纪要、AI 率自查。
**绝大部分功能在本机运行，断网可用。**

---

## 平台支持

| 功能 | macOS | Windows |
|---|---|---|
| 面板（课程 / 翻译 / 语音 / 检测 四个标签） | ✅ | ✅ |
| 快速翻译（opus-mt + 术语表） | ✅ | ✅ |
| AI 率检测（文本 / Word / 文字版 PDF） | ✅ | ✅ |
| 图片、扫描版 PDF 识别 | ✅（Vision OCR） | ❌ 需另外装 OCR 组件 |
| 语音转写 + 说话人分离 | ✅ | ⚠️ 需 `-Full` 安装，未实测 |
| 精准翻译（7B，MLX） | ✅ | ❌ 仅 macOS |
| 课程数据（CN） | ✅ | ✅ 需你自己的登录 |

> macOS 上语音与 OCR 用的是系统原生能力（Vision、LaunchAgent），所以最完整。
> Windows 版按跨平台写法实现，但**没有在 Windows 机器上实测过**，遇到问题请带着日志反馈。

---

## 安装（两步）

### 第 1 步：装本地服务

**macOS**

```bash
cd study-suite
./install.sh          # 约 200MB：翻译 + 文本检测
./install.sh --full   # 约 5GB：再加语音识别、说话人分离、7B 精准翻译
```

**Windows（PowerShell）**

```powershell
cd study-suite
powershell -ExecutionPolicy Bypass -File install.ps1
powershell -ExecutionPolicy Bypass -File install.ps1 -Full
```

两个脚本做同样四件事：建目录、装 Python 依赖、下模型、注册开机启动（macOS 是 LaunchAgent，Windows 是启动文件夹里的 cmd）。

### 第 2 步：装面板

DeepSeek Harness → **设置 → 插件 → 从文件夹安装** → 选择 `study-suite/plugin` 目录。
装好后侧栏出现「学习助手」图标。

> 想改成"输入一个包名就装"？看 [PUBLISH.md](PUBLISH.md)，需要你自己的 npm 账号发布一次。

---

## 各模块的前置条件

**课程**：需要你自己的 CN 登录（面板的课程页要有数据才有意义）。登录态存在 `secrets/cn-state.json`，不要分享给别人。

**语音**：
- 麦克风直接用
- 网课内部声音需要虚拟声卡（macOS 用 [BlackHole](https://existential.audio/blackhole/)），
  在音频 MIDI 设置里把扬声器和虚拟声卡一起做成"多输出设备"，面板里选它作为输入

**检测**：
- 文本 / Word / 文字版 PDF 装完即用
- 图片与扫描版 PDF 需要 macOS（Vision OCR）
- 含"困惑度"的最准模式需要 7B 模型；没有时自动退化成 3 个本地信号

---

## 关于 AI 率检测（重要）

本检测是**本地启发式估算**，不是 Turnitin、GPTZero 等权威系统：

- 它衡量"用词与句式像不像机器生成"
- 人写的正式学术英语也可能到 50 分以上
- 人工改写过的 AI 文本可能降到 20 分以下
- **不能作为学术不端的证据，也不能用于申诉或自证清白**

以学校官方检测为准。面板里也写了同样的免责声明。

---


---

## 手机（iOS / Android）

手机上没有 DSH 客户端，所以**不能装这个面板**。但本地服务自带一个手机网页，同一 Wi-Fi 下用手机浏览器就能用翻译和检测。

**开启（macOS）**

```bash
./lan.command          # 开启，会打印手机访问地址
./lan.command off      # 用完关掉
```

**Windows**：在 `%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\study-suite.cmd` 里加一行
`set CN_INTERPRETER_HOST=0.0.0.0`，重新登录后生效；地址是 `http://<电脑IP>:8791/`。

**手机上能做什么**

| 功能 | 手机 |
|---|---|
| 英中互译（含中英对照、快速/精准切换） | ✅ |
| AI 率检测（粘贴文字 / 选文件 / 拍照上传） | ✅ |
| 录音转写 | ❌ 浏览器只在 HTTPS 下给麦克风权限，局域网 http 拿不到 |
| 课程动态 | ❌ 手机页没做这一块 |

**安全提醒**：开启后同一 Wi-Fi 下任何人都能访问，且没有密码。建议只在家里的网络开，用完执行 `./lan.command off`。

## 卸载

**macOS**

```bash
./install.sh --uninstall
```

**Windows**

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1 -Uninstall
```

面板：设置 → 插件 → 卸载「学习助手」。

---


---

## 出问题了先跑自检

| 平台 | 命令 |
|---|---|
| macOS | 双击 `doctor.command`（或 `./doctor.command`） |
| Windows | 右键 `doctor.ps1` → 使用 PowerShell 运行 |

它会依次检查：系统信息、Python 版本、安装目录、依赖、模型、OCR 组件、服务进程、端口健康、
翻译与检测功能、CORS、最近日志，最后给出一句结论。

**出问题时把整段输出复制发给开发者** —— 里面不含你的登录凭据，只有版本号、路径、报错和最后几行日志。

## 常见问题

**面板显示"连不上本地服务"**
服务没起来。macOS：`tail -30 ~/.dsh-study-suite/service.log`；Windows：看 `%USERPROFILE%\.dsh-study-suite` 下的日志，或手动 `python serve_translate.py` 看报错。

**翻译很慢**
精准模式首次要加载 7B 模型约 2 秒；空闲 5 分钟自动卸载省内存，下次再加载。日常建议用「快速」。

**上传 PDF 提示没有文字层**
那是扫描件。macOS 上装 Xcode 命令列工具后重跑 `install.sh` 会自动编译 OCR；Windows 暂不支持。

**想换端口**
改服务环境变量 `CN_INTERPRETER_PORT`，同时改面板 `client.js` 里的 `http://127.0.0.1:8791`（共 3 处）。

**想手动启动调试**
macOS：`./start.command`。Windows：直接 `python %USERPROFILE%\.dsh-study-suite\serve_translate.py`。
