#!/usr/bin/env python3
"""End-to-end smoke test for the local service.

    python3 smoke.py            # 默认 127.0.0.1:8791
    CN_INTERPRETER_PORT=8797 python3 smoke.py

Exits non-zero if any check fails. No third-party dependencies.
"""
import json
import os
import sys
import urllib.error
import urllib.request

PORT = os.environ.get("CN_INTERPRETER_PORT", "8791")
HOST = os.environ.get("CN_INTERPRETER_HOST", "127.0.0.1")
BASE = "http://%s:%s" % (HOST, PORT)

results = []


def check(name, fn):
    try:
        detail = fn()
        results.append((True, name, detail or ""))
    except Exception as err:
        results.append((False, name, str(err)[:160]))


def get(path, timeout=15):
    with urllib.request.urlopen(BASE + path, timeout=timeout) as resp:
        return json.load(resp)


def post(path, payload, timeout=120):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(BASE + path, data=data, headers={"content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.load(resp)


def _beam_case(post):
    """beam 越界应被收敛或拒绝，不能抛 500。"""
    try:
        post("/translate", {"text": "hello world", "to": "zh", "beam": -5}, timeout=30)
    except urllib.error.HTTPError as err:
        if err.code == 400:
            return "HTTP 400"
        raise AssertionError("beam=-5 返回 %s，既不是 200 也不是 400" % err.code)
    return "已收敛"


def main():
    health = {}

    def do_health():
        nonlocal health
        health = get("/health")
        if not health.get("ok"):
            raise AssertionError("健康检查未返回 ok")
        caps = health.get("capabilities") or {}
        return "平台 %s · 线程 %s · 术语 %s" % (
            health.get("platform"), caps.get("mtThreads"), (health.get("glossary") or {}).get("en_zh"))

    check("GET /health", do_health)

    check("POST /translate en→zh", lambda: post(
        "/translate", {"text": "Submit the literature review before Week 6.", "to": "zh", "engine": "fast"}
    )["text"][:40])

    check("POST /translate zh→en", lambda: post(
        "/translate", {"text": "请在第六周之前提交文献综述。", "to": "en", "engine": "fast"}
    )["text"][:40])

    check("POST /translate/batch", lambda: "%d 行" % len(post(
        "/translate/batch", {"lines": ["Assessment 3 is due in Week 6.", "Submit it on CN."], "to": "zh"}
    )["lines"]))

    check("POST /aidetect", lambda: "评分 %s" % post(
        "/aidetect", {"text": "Plastic waste breaks into small pieces and stays in the ocean for decades. "
                              "Fish mistake it for food, and plastic enters the food chain."}
    )["score"])

    def expect_field(path, field):
        data = get(path)
        if field not in data:
            raise AssertionError("%s 没有返回 %s 字段（得到 %s）" % (path, field, sorted(data)))
        value = data[field]
        if value is None:
            raise AssertionError("%s.%s 是 null" % (path, field))
        return value

    check("GET /plan", lambda: "%d 条待办" % len(expect_field("/plan", "items") or []))
    check("GET /timetable", lambda: "%d 节课" % len(expect_field("/timetable", "classes") or []))
    check("GET /filters", lambda: "%d 条过滤" % len(expect_field("/filters", "filters") or {}))
    check("GET /hidden", lambda: "%d 门隐藏" % len(expect_field("/hidden", "names") or []))

    def expect_400(path, payload, label):
        try:
            post(path, payload, timeout=30)
        except urllib.error.HTTPError as err:
            if err.code != 400:
                raise AssertionError("%s 应返回 400，实际 %s" % (label, err.code))
            return "HTTP 400"
        raise AssertionError("%s 没有被拒绝" % label)

    check("非法 to 被拒", lambda: expect_400("/translate", {"text": "hello", "to": "klingon"}, "非法 to"))
    check("beam=-5 被拒/收敛", lambda: _beam_case(post))

    caps = (health.get("capabilities") or {})
    if caps.get("llm"):
        check("POST /translate (7B)", lambda: post(
            "/translate", {"text": "Write the literature review section.", "to": "zh", "engine": "llm"}, timeout=300
        )["text"][:40])
    else:
        try:
            post("/translate", {"text": "test", "to": "zh", "engine": "llm"}, timeout=30)
            results.append((False, "7B 应被拒绝却没拒绝", ""))
        except urllib.error.HTTPError as err:
            results.append((err.code == 400, "7B 在无 MLX 平台返回 400", "HTTP %s" % err.code))
        except Exception as err:
            results.append((False, "7B 平台检查", str(err)[:80]))

    print("=" * 56)
    for ok, name, detail in results:
        print("  %s %-28s %s" % ("[OK]  " if ok else "[FAIL]", name, detail))
    failed = sum(1 for ok, _, _ in results if not ok)
    print("=" * 56)
    print(" 结论：%s" % ("全部通过" if failed == 0 else "%d 项失败" % failed))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
