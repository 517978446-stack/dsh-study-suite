#!/bin/bash
# 开启 / 关闭「手机访问」（macOS）
#   ./lan.command          开启（允许同一 Wi-Fi 下的手机访问）
#   ./lan.command off      关闭（只允许本机访问）
set -euo pipefail
LABEL="com.local.cn-interpreter"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
PORT="${CN_INTERPRETER_PORT:-8791}"

if [ ! -f "$PLIST" ]; then
  echo "找不到登录项：$PLIST"
  echo "先把服务装好（./install.sh），再回来运行这个脚本。"
  exit 1
fi

MODE="${1:-on}"

/usr/bin/python3 - "$PLIST" "$MODE" <<'PY'
import plistlib, sys
path, mode = sys.argv[1], sys.argv[2]
data = plistlib.load(open(path, 'rb'))
env = data.setdefault('EnvironmentVariables', {})
env['CN_INTERPRETER_HOST'] = '127.0.0.1' if mode == 'off' else '0.0.0.0'
plistlib.dump(data, open(path, 'wb'))
print('监听地址 ->', env['CN_INTERPRETER_HOST'])
PY

launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
sleep 6

if curl -s --max-time 5 "http://127.0.0.1:$PORT/health" >/dev/null; then
  echo "服务已重启。"
else
  echo "服务没起来，看日志： tail -20 \"\${STUDY_SUITE_HOME:-\$HOME/.dsh-study-suite}/service.log\""
  exit 1
fi

if [ "$MODE" = "off" ]; then
  echo "已关闭手机访问：现在只有这台电脑能连。"
  exit 0
fi

IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || true)
echo
echo "手机访问地址（手机和电脑要连同一个 Wi-Fi）："
if [ -n "$IP" ]; then
  echo "   http://$IP:$PORT/"
else
  echo "   没检测到 Wi-Fi IP。到 系统设置 → Wi-Fi → 详细信息 里看「IP 地址」，替换下面的 <电脑IP>"
  echo "   http://<电脑IP>:$PORT/"
fi
echo
echo "注意："
echo "  · 同一 Wi-Fi 下任何人都能打开这个地址并使用服务（没有密码）"
echo "  · 课程动态接口也在其中，建议只在家里的网络开启，用完执行 ./lan.command off"
echo "  · 手机上不能录音（浏览器要求 HTTPS 才给麦克风权限），录音请用电脑上的面板"
