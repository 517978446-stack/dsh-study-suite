# 把面板发布成「插件链接」（需要你自己的 npm 账号）

发布之后，朋友那边就不用选文件夹了，直接：

```
设置 → 插件 → 从文件夹/包安装 → 输入 dsh-study-suite@3.6.0
```

## 步骤

1. 改名字和作者（`plugin/package.json`）

```json
{
  "name": "dsh-study-suite",
  "version": "3.6.0",
  "private": false,
  "description": "本地学习面板：课程、英中互译、语音纪要、AI 率自查",
  "license": "MIT",
  "author": "你的名字",
  "repository": { "type": "git", "url": "https://github.com/you/dsh-study-suite" }
}
```

> `name` 必须全局唯一。如果你有 scope，用 `@你的名字/dsh-study-suite` 更稳。
> `private: true` 必须改成 `false`，否则 npm 拒绝发布。

2. 登录并发布

```bash
cd plugin
npm login            # 浏览器里授权一次
npm publish          # 公开包
```

3. 验证

```bash
npm view dsh-study-suite version
```

4. 告诉朋友装这个包（面板会自动从 npm 拉取）

## 注意

- **只把 `plugin/` 发布到 npm**：里面是面板代码（约 90KB），不含模型、不含你的登录态。
- 本地服务（`service/`）仍然要让朋友跑 `install.sh` / `install.ps1`，因为它要下载几 GB 模型、还要注册开机启动 —— npm 包不适合做这些。
- 如果以后想进「插件市场」列表，需要一个索引 JSON（格式要按 DSH 的市场规范来），可以再找我写。
