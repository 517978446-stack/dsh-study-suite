# 更新日志

## 7.2.1 — 2026-10-28

**文档**
- `dev/README.md` 增加发版流程：解压 → `install.ps1` → `python %USERPROFILE%\.dsh-study-suite\smoke.py`
- `INSTALL.md` 说明装完可用 `smoke.py` 做 12 项快速验证
- 仓库 README 的自检说明同步更新

## 7.2.0 — 2026-10-28

**翻译接口的参数校验**
- `to` 走白名单：`zh / zh-cn / zh-hans / zh-hant / cn / chinese` → 英译中，
  `en / en-us / en-gb / english` → 中译英，其余返回 400。此前 `to=zh-cn` 会被
  静默当成 `zh_en`，把英文原文反向翻译成英文
- `beam` 收敛到 1–8，非整数返回 400；此前 `beam=-5` 会 500 并吐出 ctranslate2 原始报错
- `to` 不是字符串时返回 400，不再 500

**并发解码**
- `_LOCK_MT` 改为只保护引擎**加载**，解码不再串行
- 新增 `_MT_ACTIVE` 活跃计数：闲置卸载前检查，保证不会抽走正在使用的模型
- 实测：20k 字符长文档翻译期间，另一条短句从「排队 ~4 秒」降到 **28 ms**
- 压测：1 秒空闲阈值的实例上持续 45 秒、923 次请求 **0 失败**；空闲后正常卸载

**自检脚本**
- `smoke.py` 从 10 项扩到 12 项：补 `to` 非法值、`beam` 越界两个用例
- 去掉 `assert`（`python -O` 下会被跳过），改为显式抛错
- `/plan` `/timetable` `/filters` `/hidden` 改为校验字段存在性，字段改名会失败而不是显示 0 条通过

## 7.1.2 — 2026-10-28

**采纳外部评审的三处改进**
- 安装时把 `smoke.py` 一并拷到安装目录：解压包删掉后仍可随时自检
- `dev/backup.ps1` 默认**不备份 `secrets/`**（`cn-state.json` 是明文登录 cookie，传网盘等于交出账号），需要时加 `-IncludeSecrets` 并给出警告
- Release workflow 改用 runner 自带的 `gh`，去掉第三方 action；已存在 Release 时走 `--clobber` 补传，重复触发不失败

## 7.1.1 — 2026-10-28

**把编码问题变成机制，而不是靠记性**
- 三个 `.ps1` 统一为 UTF-8 带 BOM + CRLF
- 新增 `.gitattributes`：`.ps1/.cmd/.vbs` 强制 CRLF，`*.zip` 标记为二进制
- 新增 `dev/check-encoding.py`：检查仓库脚本**和** `packages/*.zip` 里的脚本
- 新增 CI：每次 push 跑编码检查，打 tag 时自动创建 Release 并上传安装包

**新增**
- `dev/backup.ps1`：备份笔记、登录态、待办、课表（不含模型）
- `.github/workflows/release.yml`：tag 即发布，不用手动传包

## 7.1.0 — 2026-10-28

**移除手机端**
- 删掉 `/mobile` 页面（210 行 HTML）和 `lan.command` 局域网开关
- 服务绑定回到 `127.0.0.1`，不再暴露给同网段的其它设备
- 根路径 `/` 改为一张简单的状态页

**日志轮转**
- 服务启动包装脚本：日志超过 5MB 自动改名 `.1`，避免长期运行时无限增长

## 7.0.0 — 2026-10-28（收尾版本）

这是把 3.x 以来所有反馈都收敛后的稳定版本。

**Windows 安装链路彻底打通**
- 服务改用 `pythonw.exe` 无窗口运行：关掉窗口不会再带走整个服务（Intel Fortran/MKL 在控制台收到 CLOSE 事件会直接 abort）
- 开机启动改为 `Startup\study-suite.vbs` → `cmd /c run-service.cmd`，全程不弹黑窗
- 服务通过 WMI `Win32_Process.Create` 启动，不再挂在 DSH 的 Job 对象里，DSH 重启不会杀掉服务
- 安装前先停旧服务再装依赖，修掉 `WinError 5: ctranslate2.dll 被占用`
- 生成的 `.cmd` / `.vbs` 统一 CRLF：LF 批处理会让 cmd 解析错位，吞掉 `set PYTHONPATH`
- 等待服务启动延长到 40 秒并显示进度；失败时直接打印 `service.log` 末尾 12 行
- `Stop-Server` 只停当前安装目录的进程，不再误杀用 `STUDY_SUITE_HOME` 跑的第二套

**能力与降级**
- 面板读取 `/health` 的 `capabilities`，按平台禁用 7B、语音、图片 OCR，不再让用户点了才吃 400
- `asr` 只看依赖是否安装，`asrModelReady` 单独表示模型是否已下载 —— 修掉「刚装 -Full 反而永远不能点」的死锁
- 能力探测收敛为共享 store：单次 `/health`、15 秒缓存、失败全部降级
- 「重试连接」强制刷新，绕过缓存

**翻译**
- 7B 提示词收紧：不再把作业说明当作文题目续写，输出长度按输入限制，跑偏自动退回快速引擎
- 解码线程按半核数封顶 8（24 核全开反而慢 38%）
- 移除失效的术语占位符方案（CTranslate2 会把标记拆成「第 N 节」）；术语表只作用于 7B，响应返回 `glossaryUsed`
- 中英对照 PDF：完整原文 + 逐段翻译，后台生成带进度条，缓存复用

**AI 率检测**
- 按真实样本重标定：修掉把学生自己文章判成「可能含 AI」的误报（53 → 0）
- 新增 AI 套话信号（中英各一套）、困惑度决定性规则、短样本保护
- 中文支持按字折算词数

**隐私**
- 移除硬编码的个人课程表（原来任何人安装都会看到作者 8 门课的名字和链接）
- 服务端默认路径改为按脚本位置推断，源码不再包含用户名与目录
- 打包前自动扫描敏感字符串

**工程**
- 新增 `service/smoke.py`：一条命令跑通 10 个接口的自检
- 构建时对产物做反向校验，防止「代码改了但没进包」

## 6.x 及更早

- 6.8.x：行尾、Job 对象、能力判定、隐私
- 6.6/6.7：能力按平台禁用、课表空态、共享 health
- 6.5.x：pythonw、日志轮转、CRLF
- 6.x 之前：学习台（课程/课表/待办）、同传翻译、AI 检测、中英对照 PDF、移动端页面、Windows 安装包
